import os
import sys
import pandas as pd

if len(sys.argv) > 1:
	filepath = sys.argv[1]
	filename_w_ext = os.path.basename(filepath)
	filename, file_extension = os.path.splitext(filename_w_ext)
	#print(filename)
	df1 = pd.read_csv(filepath, sep=',')
	df1.fillna(method='ffill', inplace=True)  # forward fill NaN 
	df1['TIME'] = pd.to_datetime(df1['DATE'])
	df1['YEAR'] = pd.DatetimeIndex(df1['TIME']).year
	df1['MONTH'] = pd.DatetimeIndex(df1['TIME']).month
	df1.set_index('TIME', inplace=True)

	#g = df1.groupby(pd.Grouper(freq="M")).mean()  #(A) group by days for each month: 2012-01, 2012-02,..., 2012-12, 2013-01...
	g = df1.groupby(df1.index.month).mean()  #(B) group by months over the years: 01, 02, 03 ... 12
	g['SCOREMAX'] = (g['TMAX'] - 71.6).abs()
	g['SCOREMIN'] = (g['TMIN'] - 71.6).abs()
	g['SCORETOT'] = g['SCOREMAX'] + g['SCOREMIN']

	#g['YEAR'] = g['YEAR'].apply(str)  #(A) only if group by days for each month
	#g['MONTH'] = g['MONTH'].map("{:02}".format).apply(str)  #(A) only if group by days for each month
	#g['DATE'] = g['YEAR'].map(str) + "-" + g['MONTH']  #(A) only if group by days for each month
	g['DATE'] = g['MONTH']  #(B)

	g['CITY'] = filename.upper()  # change lowercase city filename to uppercase
	#print(g)
	df2 = g[['DATE', 'CITY', 'LATITUDE', 'LONGITUDE', 'ELEVATION', 'PRCP', 'TMAX', 'TMIN', 'SCORETOT']].copy()
	df2 = df2.round({'LATITUDE':5, 'LONGITUDE':5, 'ELEVATION':2, 'PRCP':4, 'TMAX':2, 'TMIN':2, 'SCORETOT':2})  #(A)
	#print(df2)
	#df2.to_csv(filename+'_clean.csv', float_format='%.4f', index=False)
	df2.to_csv(filename+'_clean.csv', index=False)

else:
	print("Usage: python weatherscript.py austin/austin.csv")